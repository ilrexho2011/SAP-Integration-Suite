/* https://computerhouse.al */
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
def nr1 = message.getHeader("num1", String).toDouble()
def nr2 = message.getHeader("num2", String).toDouble()

def result = nr1 * nr2

// Set the result in the message body
message.setBody("<result>" + result + "</result>")

return message
}
