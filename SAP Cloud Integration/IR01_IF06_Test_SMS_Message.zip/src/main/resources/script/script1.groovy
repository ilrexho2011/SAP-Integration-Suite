import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
//Properties
def properties = message.getProperties();
myStoredText = properties.get("myStoredText");
messageText = ("So, hello from my SMS message - I also wanted to say ... " + myStoredText)
message.setProperty("MessageText", java.net.URLEncoder.encode(messageText, "UTF-8"));
message.setProperty("FromMe", "%2B18626216886")
message.setProperty("ToMe", "%2B355692099274")
return message;
}
