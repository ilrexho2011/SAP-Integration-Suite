import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Get the JSON body from incoming message
    def body = message.getBody(String)  
    def json = new JsonSlurper().parseText(body)

    // Construct the XML output
    def xml = """<Insert>
                    <Row>
                        <CustomerID>${json.customerId}</CustomerID>
                        <CustomerName>${json.customerName}</CustomerName>
                        <OrderTotal>${json.orderTotal}</OrderTotal>
                    </Row>
                 </Insert>"""

    // Set the XML as the new message body
    message.setBody(xml)
    
    return message
}