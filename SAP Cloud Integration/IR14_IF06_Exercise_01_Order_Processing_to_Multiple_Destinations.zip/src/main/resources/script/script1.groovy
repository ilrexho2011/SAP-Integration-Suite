import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.dom.DOMSource
import org.xml.sax.InputSource
import java.io.StringReader
import net.sf.saxon.dom.DOMNodeList

Message processData(Message message) {
    def body = message.getBody()

    if (body instanceof DOMNodeList) {
        if (body.length > 0 && body.item(0) != null) {
            // Convert DOMNodeList to XML String
            def xmlString = body.item(0).textContent

            // Parse XML String into a Document
            def dbFactory = DocumentBuilderFactory.newInstance()
            def dBuilder = dbFactory.newDocumentBuilder()
            def xmlDocument = dBuilder.parse(new InputSource(new StringReader(xmlString)))

            // Convert Document to DOMSource
            message.setBody(new DOMSource(xmlDocument))
        } else {
            throw new Exception("Error: DOMNodeList is empty or invalid")
        }
    } else {
        throw new Exception("Error: Message body is not of type DOMNodeList")
    }
    
    return message
}
