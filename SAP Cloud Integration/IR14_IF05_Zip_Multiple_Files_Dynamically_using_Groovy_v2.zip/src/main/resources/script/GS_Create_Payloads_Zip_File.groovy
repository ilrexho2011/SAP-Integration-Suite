/* https://computerhouse.al */
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.zip.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    def payload_people = properties.get("payload_people").getBytes("UTF-8")
    def payload_org = properties.get("payload_org").getBytes("UTF-8")

    ByteArrayOutputStream baos = new ByteArrayOutputStream()
    ZipOutputStream zos = new ZipOutputStream(baos)

    ZipEntry entry = null

    AddZipEntry(zos, "people.csv", payload_people)
    AddZipEntry(zos, "org.csv", payload_org)

    if(properties.get("payload_pdf") != null) {
        def payload_sample_pdf = properties.get("payload_pdf") as byte[]
        AddZipEntry(zos, "sample.pdf", payload_sample_pdf)
    }

    zos.close()

    message.setBody(baos)
    headers.put("Content-Type", "application/zip")

    return message
}

def AddZipEntry(def zos, String filename, def payload_bytes){
    ZipEntry entry = new ZipEntry(filename)
    entry.setSize(payload_bytes.length)
    zos.putNextEntry(entry)
    zos.write(payload_bytes)
    zos.closeEntry()
}