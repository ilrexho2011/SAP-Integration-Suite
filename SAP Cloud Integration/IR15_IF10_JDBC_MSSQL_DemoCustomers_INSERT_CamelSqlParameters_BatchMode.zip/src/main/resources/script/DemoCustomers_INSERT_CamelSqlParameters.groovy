import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	message.setBody('INSERT INTO DemoCustomers (CustomerID, CompanyName) VALUES (?, ?)')

    def paramList = []
    def param = []
    
    param = []
    param.add('AAAAA')
    param.add('A Name from CamelSqlParameters')
    paramList.add(param)
    
    param = []
    param.add('BBBBB')
    param.add('B Name from CamelSqlParameters')
    paramList.add(param)
    
    param = []
    param.add('CCCCC')
    param.add('C Name from CamelSqlParameters')
    paramList.add(param)
    
    
    message.setHeader("CamelSqlParameters", paramList)
    
    return message
}