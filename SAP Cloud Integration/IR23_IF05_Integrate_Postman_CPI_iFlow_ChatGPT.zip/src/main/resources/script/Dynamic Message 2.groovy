import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    // Read the XML body as a String
    def body = message.getBody(String)

    // Parse the XML using XmlSlurper (supported in CPI)
    def parsedXml = new XmlSlurper().parseText(body)

    // Navigate to <content> and extract the text
    def contentText = parsedXml.choices.message.content.text()

    // Set only the content text as the new message body
    message.setBody(contentText)

    return message
}
