import com.sap.it.api.mapping.*;
def String checkEmptyText(String fieldValue) {
    return (fieldValue == null || fieldValue.trim().isEmpty()) ? "Unknown Customer" : fieldValue
}