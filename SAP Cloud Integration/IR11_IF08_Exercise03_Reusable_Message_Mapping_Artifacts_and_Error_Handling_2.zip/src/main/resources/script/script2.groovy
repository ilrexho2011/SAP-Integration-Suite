import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def errorList = []
    xml.Order.each { order ->
        def errors = []
        if (!order.CustomerName.text()) {
            errors << "Missing mandatory field: CustomerName"
        }
        if (!order.TotalAmount.text().isNumber()) {
            errors << "Invalid TotalAmount value."
        }
        if (errors) {
            errorList << [OrderID: order.OrderID.text(), Message: errors.join(" or ")]
        }
    }

    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)
    xmlBuilder.Errors {
        errorList.each { error ->
            Error {
                OrderID(error.OrderID)
                Message(error.Message)
            }
        }
    }
    
    message.setBody(writer.toString())
    return message
}