import com.sap.it.api.mapping.*;

def String validateAmount(int amount) {
    try {
        return amount as BigDecimal
    } catch (Exception e) {
        throw new RuntimeException("Invalid TotalAmount value: ${amount}")
    }
}