import com.sap.it.api.mapping.*;

def String convertCurrency(String amount, String currency) {
    def conversionRates = ['USD': 84.50, 'EUR': 92.30] // Example rates
    try {
        def convertedAmount = (amount as BigDecimal) * (conversionRates[currency] ?: 1)
        return convertedAmount
    } catch (Exception e) {
        throw new RuntimeException("Deshtoi konvertimi per: ${amount} ${currency}")
    }
}