import com.sap.it.api.mapping.*;

def String checkMandatoryField(String fieldValue) {
    if (fieldValue == null || fieldValue.trim().isEmpty()) {
        throw new RuntimeException("Mungon emri ne fushen CustomerName")
    }
    return fieldValue
}