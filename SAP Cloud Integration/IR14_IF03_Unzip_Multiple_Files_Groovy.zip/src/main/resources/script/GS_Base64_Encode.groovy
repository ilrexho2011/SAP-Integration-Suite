/* https://computerhouse.al */
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body_bytes = message.getBody(byte[])
   
    message.setBody(body_bytes.encodeBase64().toString())

    return message
}










