import com.sap.gateway.ip.core.customdev.util.Message
import java.io.InputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.stream.Collectors

Message processData(Message message) {
    // Read the body as an InputStream
    InputStream bodyStream = message.getBody(InputStream)
    
    // Convert InputStream to String (Java 8 compatible way)
    BufferedReader reader = new BufferedReader(new InputStreamReader(bodyStream, StandardCharsets.UTF_8))
    String body = reader.lines().collect(Collectors.joining("\n"))

    // Ensure the body is not empty
    if (body == null || body.trim().isEmpty()) {
        throw new RuntimeException("Message body is empty! Cannot wrap Employees element.")
    }

    // Wrap the multiple <Employee> nodes inside <Employees>
    String wrappedXml = "<Employees>${body}</Employees>"

    // Set the modified XML as the new message body
    message.setBody(wrappedXml)

    return message
}