import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    
 def body = message.getBody();
 
 message.setHeader("Team_2", "South Africa");
 
 message.setProperty("Score_2", "169-8");
 
 return message;
}