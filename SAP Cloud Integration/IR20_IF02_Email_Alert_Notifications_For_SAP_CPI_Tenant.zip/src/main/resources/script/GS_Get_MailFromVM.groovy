import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String);
    def xml_body = new XmlSlurper().parseText(body);
    
    def iFlowName = ''
    
    xml_body.Record.Error.each { row ->
    iFlowName = row.iFlowName.text()
    }
    
    message.setHeader('iFlowName',iFlowName);

    def propertyMap = message.getProperties();
    def ToMail = propertyMap.get("defaultToMail");

    def valueMap = ITApiFactory.getApi(ValueMappingApi.class,null)

    def VM_ToMail= valueMap.getMappedValue('IntegrationFlow', 'Name', iFlowName, 'Recipient', 'EmailID');
 

    if(VM_ToMail && VM_ToMail != ''){
     message.setProperty("MailTo", VM_ToMail);
    } 
    else {
        message.setProperty("MailTo", ToMail);
    }
    
    return message;
}
