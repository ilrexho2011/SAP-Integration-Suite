import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    try {
        // Parse XML Body
        def xml = new XmlSlurper().parseText(message.getBody(String))

        // Get properties
        def prop = message.getProperties()
        def tableName = prop.get("TableName")

        // Validate table name
        if (!tableName) {
            throw new RuntimeException("TableName property is missing.")
        }

        // Match table name exactly
        def temptableName = "\"SAPCPI_MessageProcessingLogs\"" 

        // Start SQL statement
        def sqlQuery = "INSERT INTO ${temptableName} (\"MessageID\", \"CorrelationID\", \"ApplicationMessageId\", \"Status\", \"IntegrationFlowName\", \"PackageName\", \"LogTime\", \"ExceptionMessage\", \"MonitorLink\") \n"

        // Process each record safely
        def selects = xml.Records.collect { log ->
            def messageID = log.MessageID?.text() ?: ""
            def correlationID = log.CorrelationID?.text() ?: ""
            def applicationMessageId = log.ApplicationMessageId?.text() ?: ""
            def status = log.Status?.text() ?: ""
            def integrationFlowName = log.IntegrationFlowName?.text() ?: ""
            def packageName = log.PackageName?.text() ?: ""
            def logTime = log.LogTime?.text() ?: ""  // Consider formatting this as a TIMESTAMP if needed
            def exceptionMessage = log.ExceptionMessage?.text()?.replace("'", "''") ?: ""
            def monitorLink = log.MonitorLink?.text() ?: ""

            """SELECT '${messageID}', '${correlationID}', '${applicationMessageId}', '${status}', '${integrationFlowName}', '${packageName}', '${logTime}', '${exceptionMessage}', '${monitorLink}' FROM DUMMY"""
        }

        // Check if there are records
        if (selects.isEmpty()) {
            throw new RuntimeException("No records found in XML input.")
        }

        // Combine SELECTs with UNION ALL
        sqlQuery += selects.join("\nUNION ALL\n") + ";"

        // Set the generated SQL as the message body
        message.setBody(sqlQuery)
    } catch (Exception e) {
        message.setBody("Error processing XML: " + e.message)
    }

    return message
}