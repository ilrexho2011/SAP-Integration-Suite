import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*
import groovy.json.*

def Message processData(Message message) {
    
    def props = message.getProperties()
    def events = []
    def mlps = new XmlSlurper(false, true).parse(message.getBody(Reader.class))
	def groupedFlowIds = mlps.MessageProcessingLog.groupBy { entry -> entry.IntegrationArtifact.Id.toString() }
    
    groupedFlowIds.each { def key, def value ->
		events.add(relevantNotification(key, value, props))
	}
	
	message.setBody(JsonOutput.toJson(events))
    return message;
}

def relevantNotification(def flowId, def messages, def props){
    def flowName = messages[0].IntegrationArtifact.Name.toString()
	def flowType = messages[0].IntegrationArtifact.Type.toString()
	def packageId = messages[0].IntegrationArtifact.PackageId.toString()
	def packageName = messages[0].IntegrationArtifact.PackageName.toString()
	def cpiTenantBaseUrl = props.get("CPI_Tenant_Base_URL")
	def currentTimeFrameEnd = props.get("NOW_TIMESTAMP")
	def currentTimeFrameStart = props.get("LAST_END_TIMESTAMP")
	def adjustedCpiTenantBaseUrl = cpiTenantBaseUrl.endsWith('/') ? cpiTenantBaseUrl.substring(0, cpiTenantBaseUrl.length() - 1) : cpiTenantBaseUrl
	def cpiMonitoringUrl = "${adjustedCpiTenantBaseUrl}/itspaces/shell/monitoring/Messages/%7B%22time%22:%22CUSTOM%22,%22from%22:%22${URLEncoder.encode(currentTimeFrameStart, 'UTF-8')}Z%22,%22to%22:%22${URLEncoder.encode(currentTimeFrameEnd, 'UTF-8')}Z%22,%22artifact%22:%22${URLEncoder.encode(flowId, 'UTF-8')}%22,%22status%22:%22FAILED%22%7D"
	def integrationFlowUrl = "${adjustedCpiTenantBaseUrl}/itspaces/shell/design/contentpackage/${URLEncoder.encode(packageId, 'UTF-8')}/integrationflows/${URLEncoder.encode(flowId, 'UTF-8')}"
	
	Event event = new Event(
			eventType: "CPIIntegrationFlowExecutionFailure",
			resource: new Resource(
					resourceName: flowName,
					resourceType: flowType
			),
			severity: "INFO",
			category: "NOTIFICATION",
			subject: "CPI Integration Flow '${flowName}': Execution Failure",
			body: "There were '${messages.size()}' failures for the '${flowName}' integration flow within the time frame starting from '${currentTimeFrameStart}' and ending at '${currentTimeFrameEnd}'. ",
			tags: [
					'ans:detailsLink'                    : cpiMonitoringUrl,
					'cpi:IntegrationArtifact.Id'         : flowId,
					'cpi:IntegrationArtifact.Name'       : flowName,
					'cpi:IntegrationArtifact.PackageId'  : packageId?.trim() ? packageId : "NOT_AVAILABLE",
					'cpi:IntegrationArtifact.PackageName': packageName?.trim() ? packageName : "NOT_AVAILABLE",
					'cpi:IntegrationFlowUrl'             : packageId?.trim() ? integrationFlowUrl : "NOT_AVAILABLE",
					'cpi:MessageFailureCount'            : messages.size()
			]
	)
	
	return event
}

class Event {
	def eventType
	Resource resource
	def severity
	def category
	def subject
	def body
	def tags

}

class Resource {
	def resourceName
	def resourceType
}
