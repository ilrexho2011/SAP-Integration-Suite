import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
     Reader body = message.getBody(Reader)
     Writer myXML = new StringWriter()
     def indentPrinter = new IndentPrinter(myXML, '    ')
     def builder = new MarkupBuilder(indentPrinter)
        builder.Oscars {
            Winners (Year : '2006') {
                'Best_Film' 'Crash'
                    Best_Actor {
                    'Name' 'Philip Seymour Hoffman'
                    'Film' 'Capote'
                    }
                    Best_Actress {
                     'Name' 'Reese Witherspoon'
                     'Film' 'Walk the Line'
                        }
                    }
        } 
     //Setting message body with writer object
     message.setBody(myXML.toString())
     return message
}