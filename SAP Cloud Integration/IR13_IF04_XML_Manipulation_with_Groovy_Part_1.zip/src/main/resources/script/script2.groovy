import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
     Reader body = message.getBody(Reader)
     Writer myXML = new StringWriter()
     def indentPrinter = new IndentPrinter(myXML, '    ')
     def builder = new MarkupBuilder(indentPrinter)
     int x = 2020
         builder.Oscars {
            while (x < 2024) {
                Winners (Year : x) {
                    if (x < 2022) {
                        myFilm = "This Film won in " + x
                    } else {
                        myFilm = "Rocky " + ( x - 2020)
                    }
                    'Best_Film' myFilm
         
                    Best_Actor {
                    'Name' 'Philip Seymour Hoffman'
                    'Film' 'Capote'
                    }
                    Best_Actress {
                        'Name' 'Reese Witherspoon'
                        'Film' 'Walk the Line'
                    }
                }
            x++ 
            }
        } 
     //Setting message body with writer object
     message.setBody(myXML.toString())
     return message
}
