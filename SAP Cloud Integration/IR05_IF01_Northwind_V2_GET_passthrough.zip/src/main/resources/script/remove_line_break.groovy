import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*
import java.text.*
import java.time.*
import java.time.format.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

def DoMapping(String body, Map headers, Map properties) {
   
    body = body.toString().replace("\n", "").replace("\r", "")

    return body
}