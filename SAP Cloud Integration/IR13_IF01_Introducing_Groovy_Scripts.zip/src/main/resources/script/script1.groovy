/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    
    //Body
    def body = message.getBody();
    
    //Properties
    def properties = message.getProperties();
    
    // Get the variables that we stored in Content Modifier
    myOrder = properties.get("OrderNo");
    myLine = properties.get("LineNo");
    
    // Use this to create new Content
    myNewText = "I have this order ("+ myOrder +") which has line number " + myLine + " on it"
    
    /* There is no need to store myNewText in order to useThatText 
    I did this only to show you the set property.
    Later will show this content saved in propertiesFrom now on we can use in our Iflow */
    message.setProperty("useThisText", myNewText);
    
    /* Just like the ${in.body} that we used in Content Modifier setBody
    is telling us what is in the output when we leave the groovy script, 
    but if we don't put this it will pass the content unchanged */
    message.setBody(myNewText);
    
    return message;
}