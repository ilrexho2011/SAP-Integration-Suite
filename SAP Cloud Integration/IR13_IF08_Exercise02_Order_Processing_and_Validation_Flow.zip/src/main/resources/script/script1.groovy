import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {
    // Get the XML payload from the message
    def body = message.getBody(String)

    // Generate the processing timestamp
    def dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    def timestamp = dateFormat.format(new Date())

    // Insert the timestamp after <customerID> using an alternative method
    def updatedBody = body.replaceFirst(
        "(<customerID>[^<]*</customerID>)",
        "\$1<processingTimestamp>${timestamp}</processingTimestamp>"
    )

    // Set the updated XML back into the message
    message.setBody(updatedBody)
    return message
}