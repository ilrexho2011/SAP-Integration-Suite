import com.sap.gateway.ip.core.customdev.util.Message

def Message log01(Message message) {processData("log01", message);}
def Message log02(Message message) {processData("log02", message);}
def Message log03(Message message) {processData("log03", message);}
def Message log04(Message message) {processData("log04", message);}
def Message log05(Message message) {processData("log05", message);}
def Message log06(Message message) {processData("log06", message);}
def Message log07(Message message) {processData("log07", message);}
def Message log08(Message message) {processData("log08", message);}
def Message log09(Message message) {processData("log09", message);}
def Message log10(Message message) {processData("log10", message);}

def Message log11(Message message) {processData("log11", message);}
def Message log12(Message message) {processData("log12", message);}
def Message log13(Message message) {processData("log13", message);}
def Message log14(Message message) {processData("log14", message);}
def Message log15(Message message) {processData("log15", message);}
def Message log16(Message message) {processData("log16", message);}
def Message log17(Message message) {processData("log17", message);}
def Message log18(Message message) {processData("log18", message);}
def Message log19(Message message) {processData("log19", message);}
def Message log20(Message message) {processData("log20", message);}

def Message log21(Message message) {processData("log21", message);}
def Message log22(Message message) {processData("log22", message);}
def Message log23(Message message) {processData("log23", message);}
def Message log24(Message message) {processData("log24", message);}
def Message log25(Message message) {processData("log25", message);}
def Message log26(Message message) {processData("log26", message);}
def Message log27(Message message) {processData("log27", message);}
def Message log28(Message message) {processData("log28", message);}
def Message log29(Message message) {processData("log29", message);}
def Message log30(Message message) {processData("log30", message);}

def Message log31(Message message) {processData("log31", message);}
def Message log32(Message message) {processData("log32", message);}
def Message log33(Message message) {processData("log33", message);}
def Message log34(Message message) {processData("log34", message);}
def Message log35(Message message) {processData("log35", message);}
def Message log36(Message message) {processData("log36", message);}
def Message log37(Message message) {processData("log37", message);}
def Message log38(Message message) {processData("log38", message);}
def Message log39(Message message) {processData("log39", message);}
def Message log40(Message message) {processData("log40", message);}

def Message log41(Message message) {processData("log41", message);}
def Message log42(Message message) {processData("log42", message);}
def Message log43(Message message) {processData("log43", message);}
def Message log44(Message message) {processData("log44", message);}
def Message log45(Message message) {processData("log45", message);}
def Message log46(Message message) {processData("log46", message);}
def Message log47(Message message) {processData("log47", message);}
def Message log48(Message message) {processData("log48", message);}
def Message log49(Message message) {processData("log49", message);}
def Message log50(Message message) {processData("log50", message);}

def Message log99(Message message) {processData("log99", message);}

def processData(Message message) {
    return logMessage("log", message)
}

def Message logMessage(String prefix, Message message) {
    def headers = message.getHeaders()
    def properties = message.getProperties()
    def body = message.getBody(String)
    
    def messageLogFactory = message.getProperty("CamelMessageLogFactory")
    def messageLog = messageLogFactory?.getMessageLog(message)
    
    def logging = properties.get("logging")

    if (logging == 'true' && messageLog != null) {
        messageLog.addAttachmentAsString(prefix, body, "text/plain")
    }
    
    return message
}

// Define multiple logging functions dynamically
definitions = [:]
(1..50).each { num -> definitions["log${num}"] = { Message message -> logMessage("log${num}", message) } }
definitions["log99"] = { Message message -> logMessage("log99", message) }

definitions.each { name, closure -> this.metaClass."$name" = closure }
