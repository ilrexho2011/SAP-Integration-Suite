import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message)
{
    def body = message.getBody(String)
    def messageLog = messageLogFactory.getMessageLog(message);
    def resolution = message.getProperty("resolution") as String
    if(messageLog != null)
    {
    messageLog.addAttachmentAsString("Resolution", resolution, "text/plain");
    }
    return message;
}
