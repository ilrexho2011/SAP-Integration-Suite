import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    
    def body = message.getBody();
    
    throw new Exception('I have deliberely thrown this error' + " - only for test purposes")

    return message;
}