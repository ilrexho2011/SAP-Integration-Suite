import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String);
    body = body.replaceAll("<MessageProcessingLog>","").trim();
    body = body.replaceAll("</MessageProcessingLog>","").trim();
    body = body.replaceAll("<MessageProcessingLogs>","").trim();
    body = body.replaceAll("</MessageProcessingLogs>","").trim();
    //body = body.replaceAll("        <?xml version="1.0" encoding="UTF-8"?>","").trim();
    body = body.replaceAll("\\\t|\\\n|\\\r","");
    message.setBody(body);
    return message;

}
