import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.xpath.*
import org.w3c.dom.*
import javax.xml.parsers.DocumentBuilderFactory
import groovy.xml.MarkupBuilder

def processData(Message message) {
    // Payload abrufen
    def body = message.getBody(String)
    
    // XML-Dokument in ein DOM-Objekt parsen
    def factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true) // Falls XML Namensräume hat
    def builder = factory.newDocumentBuilder()
    def xmlInput = new ByteArrayInputStream(body.bytes)
    def doc = builder.parse(xmlInput)
    
    // XPath für die Suche initialisieren
    def xpath = XPathFactory.newInstance().newXPath()
    
    // Fehleranzahl pro IntegrationFlow zählen
    def errorCount = [:]
    def errorDetails = [:]
    def nodes = xpath.evaluate("//ErrorMessage", doc, XPathConstants.NODESET)
    
    for (int i = 0; i < nodes.getLength(); i++) {
        def node = nodes.item(i)
        def flowName = xpath.evaluate("IntegrationFlow", node)
        def messageID = xpath.evaluate("MessageID", node)
        def logStart = xpath.evaluate("LogStart", node)
        def logEnd = xpath.evaluate("LogEnd", node)
        def errorText = xpath.evaluate("ErrorText", node)
        
        if (!errorDetails.containsKey(flowName)) {
            errorDetails[flowName] = [:]
        }
        
        if (!errorDetails[flowName].containsKey(errorText)) {
            errorDetails[flowName][errorText] = [
                count: 0,
                oldestError: [
                    messageID: messageID,
                    logStart: logStart,
                    logEnd: logEnd,
                    errorText: errorText
                ]
            ]
        }
        
        errorDetails[flowName][errorText].count++
    }
    
    // Neue XML-Struktur aufbauen
    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)
    
    xmlBuilder.ErrorSummary {
        errorDetails.each { flowName, errors ->
            IntegrationFlow(name: flowName, errorCount: errors.values().sum { it.count }) {
                errors.eachWithIndex { entry, index ->
                    def errorText = entry.key
                    def errorData = entry.value
                    "Fehler "(Count: errorData.count) {
                        MessageID(errorData.oldestError.messageID)
                        LogStart(errorData.oldestError.logStart)
                        LogEnd(errorData.oldestError.logEnd)
                        ErrorText(errorData.oldestError.errorText)
                    }
                }
            }
        }
    }
    
    // Transformiertes XML als neuen Body setzen
    message.setBody(writer.toString())
    
    return message
}
