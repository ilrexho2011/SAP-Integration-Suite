import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.NodeList
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import java.nio.charset.StandardCharsets

// Methode zur Umwandlung von Priority-String in eine Zahl
int convertPriority(String priority) {
    switch (priority?.toLowerCase()) {
        case "high": return 1
        case "medium": return 2
        case "low": return 3
        default: return 4 // Unknown oder nicht definierte Werte
    }
}

def Message processData(Message message) {
    // XML-Payload als String einlesen
    def xmlPayload = message.getBody(String)

    // XML in ein DOM-Objekt parsen
    def documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
    def inputStream = new ByteArrayInputStream(xmlPayload.bytes)
    Document document = documentBuilder.parse(inputStream)

    // 'name'-Attribut des IntegrationFlow extrahieren
    String eventType = document.getElementsByTagName("IntegrationFlow").item(0).getAttribute("name")

    // 'priority'-Attribut des IntegrationFlow extrahieren und in eine Zahl umwandeln
    String priorityString = document.getElementsByTagName("IntegrationFlow").item(0).getAttribute("priority")
    int priority = convertPriority(priorityString)

    // Fehlerknoten extrahieren
    NodeList fehlerNodes = document.getElementsByTagName("IntegrationFlow").item(0).getChildNodes()

    // StringBuilder für den Body-Text
    StringBuilder bodyBuilder = new StringBuilder()
    bodyBuilder.append("Fehlermeldung für IntegrationFlow: ").append(eventType).append("      ")

    // Durch die Fehlerknoten iterieren
    for (int i = 0; i < fehlerNodes.getLength(); i++) {
        if (fehlerNodes.item(i) instanceof Element) {
            Element fehler = (Element) fehlerNodes.item(i)
            String fehlerName = fehler.getNodeName()
            String count = fehler.getAttribute("Count")
            String messageId = fehler.getElementsByTagName("MessageID").item(0).getTextContent()
            String logStart = fehler.getElementsByTagName("LogStart").item(0).getTextContent()
            String logEnd = fehler.getElementsByTagName("LogEnd").item(0).getTextContent()
            String errorText = fehler.getElementsByTagName("ErrorText").item(0).getTextContent()

            bodyBuilder.append("   ").append(fehlerName).append("-------------")
            bodyBuilder.append("  Anzahl: ").append(count).append("-------------")
            bodyBuilder.append("  MessageID: ").append(messageId).append("-------------")
            bodyBuilder.append("  LogStart: ").append(logStart).append("-------------")
            bodyBuilder.append("  LogEnd: ").append(logEnd).append("-------------")
            bodyBuilder.append("  ErrorText: ").append(errorText).append("")
        }
    }

    // JSON-Objekt als Map erstellen
    def json = [
        eventType: eventType,
        priority: priority,
        resource: [
            resourceName: "CI/EIC",
            resourceType: "Integration"
        ],
        severity: "FATAL", // Immer 'FATAL'
        category: "ALERT",
        subject: "Integrationflow im Status Fehlerhaft",
        body: bodyBuilder.toString()
    ]

    // JSON in String umwandeln
    def jsonBuilder = new JsonBuilder(json)
    def jsonString = jsonBuilder.toPrettyString()

    // JSON-String validieren
    def jsonSlurper = new JsonSlurper()
    try {
        jsonSlurper.parseText(jsonString)
    } catch (Exception e) {
        throw new RuntimeException("Ungültiger JSON-String: ${e.message}")
    }

    // JSON-String als neue Payload setzen
    message.setBody(jsonString)

    return message
}
