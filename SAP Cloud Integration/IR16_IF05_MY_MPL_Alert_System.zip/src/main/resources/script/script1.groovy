import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory
import java.io.StringReader
import org.xml.sax.InputSource

def processData(Message message) {
    // Get the incoming payload safely as a String
    def errorTextContent = message.getBody(String)

    // Ensure it's not null or undefined
    if (errorTextContent == null) {
        errorTextContent = "No error message received."
    }

    // Ensure it's a clean string
    errorTextContent = errorTextContent.toString().trim()

    // Retrieve headers
    def status = message.getHeader("Z_Status", String) ?: "Unknown"
    def integrationFlow = message.getHeader("Z_IntegrationFlowName", String) ?: "Unknown"
    def localComponent = message.getHeader("Z_LocalComponent", String) ?: "Unknown"
    def messageGuid = message.getHeader("Z_MessageGuid", String) ?: "Unknown"
    def logStart = message.getHeader("Z_LogStart", String) ?: "Unknown"
    def logEnd = message.getHeader("Z_LogEnd", String) ?: "Unknown"

    // Manually construct the XML structure
    def newPayload = """
      <ErrorMessage>
        <LocalComponent>${localComponent}</LocalComponent>
        <IntegrationFlow>${integrationFlow}</IntegrationFlow>
        <MessageID>${messageGuid}</MessageID>
        <LogStart>${logStart}</LogStart>
        <LogEnd>${logEnd}</LogEnd>
        <Status>${status}</Status>
        <ErrorText><![CDATA[${errorTextContent}]]></ErrorText>
      </ErrorMessage>
    """

    // Validate XML before setting it as the message body
    if (isValidXML(newPayload)) {
        message.setBody(newPayload.trim())
    } else {
        message.setBody("<ErrorMessage><ErrorText>Invalid XML generated</ErrorText></ErrorMessage>")
    }

    return message
}

// Method to check if a string is valid XML
def isValidXML(String xmlContent) {
    try {
        def factory = DocumentBuilderFactory.newInstance()
        factory.setNamespaceAware(true)
        def builder = factory.newDocumentBuilder()
        def inputSource = new InputSource(new StringReader(xmlContent))
        builder.parse(inputSource)
        return true
    } catch (Exception e) {
        return false
    }
}
