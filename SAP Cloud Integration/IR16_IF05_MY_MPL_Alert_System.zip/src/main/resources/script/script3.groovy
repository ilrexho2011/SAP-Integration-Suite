import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.asdk.datastore.DataStoreService
import com.sap.it.api.asdk.runtime.Factory

import java.io.ByteArrayInputStream
import java.io.StringWriter
import java.nio.charset.StandardCharsets

import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult


def processData(Message message) {
    try {
        /************************************************************
         * STEP 1: Read Incoming Message & Extract Key Values
         ************************************************************/
        
        // Save incoming XML payload
        def incomingXML = message.getBody(String)

        // Read headers
        def headers = message.getHeaders()
        def integrationFlow = headers.get("Z_IntegrationFlow") // Extract header Z_IntegrationFlow

        // Read exchange properties
        def properties = message.getProperties()
        def dsName = properties.get("DS_Name")  // Data Store name
        def dsEntry = properties.get("DS_Entry") // Data Store entry ID

        // Extract IntegrationFlow name & errorCount from XML
        def flowDetails = extractIntegrationFlowDetails(incomingXML)
        def extractedIntegrationFlow = flowDetails.name
        def errorCount = flowDetails.errorCount

        /************************************************************
         * STEP 2: Fetch Data Store, Process CSV & Add Priority
         ************************************************************/

        // Access Data Store service
        def service = new Factory(DataStoreService.class).getService()

        if (service != null && dsName && dsEntry) {
            try {
                // Fetch CSV data from the Data Store
                def dsData = service.get(dsName, dsEntry)

                if (dsData != null) {
                    def csvData = new String(dsData.getDataAsArray(), StandardCharsets.UTF_8)

                    // Convert CSV to a map (Key = IFlow-Name, Value = Priority)
                    def priorityMap = parseCSVToMap(csvData)

                    // Determine priority for the IntegrationFlow
                    def numericPriority = priorityMap.get(extractedIntegrationFlow) ?: "Unknown"
                    def textPriority = mapPriorityToText(numericPriority)

                    // **Set priority as a new header**
                    message.setHeader("Priority", textPriority)

                    // **Add priority inside the XML payload**
                    def updatedXML = addPriorityToXML(incomingXML, extractedIntegrationFlow, errorCount, textPriority)
                    
                    // **Pretty-print and set the updated XML**
                    message.setBody(new ByteArrayInputStream(prettyPrintXML(updatedXML).getBytes(StandardCharsets.UTF_8)))
                } else {
                    setErrorResponse(message, "No Data Found in Data Store for Entry: ${dsEntry}")
                }
            } catch (Exception e) {
                setErrorResponse(message, "Error retrieving DataStore entry: ${e.message}")
            }
        } else {
            setErrorResponse(message, "Invalid Data Store Configuration: DS_Name=${dsName}, DS_Entry=${dsEntry}")
        }
    } catch (Exception e) {
        setErrorResponse(message, "Unexpected Error: ${e.message}")
    }

    return message
}

/**
 * Extracts the IntegrationFlow name and errorCount from the incoming XML
 */
def extractIntegrationFlowDetails(String xmlData) {
    def factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    def builder = factory.newDocumentBuilder()
    def doc = builder.parse(new ByteArrayInputStream(xmlData.bytes))

    def integrationFlowNode = doc.getElementsByTagName("IntegrationFlow").item(0)
    
    def name = integrationFlowNode ? integrationFlowNode.getAttribute("name") : "Unknown"
    def errorCount = integrationFlowNode ? integrationFlowNode.getAttribute("errorCount") : "0"

    return [name: name, errorCount: errorCount]
}

/**
 * Converts CSV data to a map (Key = IFlow-Name, Value = Priority)
 */
def parseCSVToMap(String csvData) {
    def map = [:] // Empty map for storing IFlow -> Priority mapping

    csvData.eachLine { line ->
        def columns = line.split(";") // CSV split by semicolon
        if (columns.length == 2) {
            def iflowName = columns[0].trim()
            def priority = columns[1].trim()

            if (!map.containsKey(iflowName)) { // Take the first occurrence
                map[iflowName] = priority
            }
        }
    }
    return map
}

/**
 * Maps numeric priority to text values
 */
def mapPriorityToText(String priority) {
    switch (priority) {
        case "1":
            return "High"
        case "2":
            return "Medium"
        case "3":
            return "Low"
        default:
            return "Unknown"
    }
}

/**
 * Adds the priority as an attribute inside <IntegrationFlow>
 */
def addPriorityToXML(String xmlData, String integrationFlow, String errorCount, String priority) {
    def factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    def builder = factory.newDocumentBuilder()
    def doc = builder.parse(new ByteArrayInputStream(xmlData.bytes))

    // Locate <IntegrationFlow> node and add priority attribute
    def integrationFlowNode = doc.getElementsByTagName("IntegrationFlow").item(0)
    if (integrationFlowNode) {
        integrationFlowNode.setAttribute("priority", priority)
    }

    // Convert XML back to a string
    def transformerFactory = TransformerFactory.newInstance()
    def transformer = transformerFactory.newTransformer()
    transformer.setOutputProperty(OutputKeys.INDENT, "yes")
    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4")

    def writer = new StringWriter()
    transformer.transform(new DOMSource(doc), new StreamResult(writer))
    
    return writer.toString()
}

/**
 * Pretty-prints XML with indentation
 */
def prettyPrintXML(String xmlData) {
    def factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    def builder = factory.newDocumentBuilder()
    def doc = builder.parse(new ByteArrayInputStream(xmlData.bytes))

    def transformerFactory = TransformerFactory.newInstance()
    def transformer = transformerFactory.newTransformer()
    transformer.setOutputProperty(OutputKeys.INDENT, "yes")
    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4")

    def writer = new StringWriter()
    transformer.transform(new DOMSource(doc), new StreamResult(writer))
    
    return writer.toString()
}

/**
 * Helper function to set error response with proper conversion
 */
def setErrorResponse(Message message, String errorMsg) {
    message.setHeader("Priority", "Error")
    def errorXML = "<Error>${errorMsg}</Error>"
    message.setBody(new ByteArrayInputStream(errorXML.getBytes(StandardCharsets.UTF_8)))
}
