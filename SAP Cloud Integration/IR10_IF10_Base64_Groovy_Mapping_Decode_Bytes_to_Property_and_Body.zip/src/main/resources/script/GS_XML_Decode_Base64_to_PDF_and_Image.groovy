/* https://computerhouse.al */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to SAP CI. This TestRun() for local debug only
//TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFile = new File("$dataDir\\XML_embedded_PDF_and_Image.txt")

    File outputFileImage = new File("$dataDir\\Image_Output.png")
    File outputFilePDF = new File("$dataDir\\PDF_Ouput.pdf")

    def inputBody = inputFile.getText("UTF-8")
    def outputBody = DoMapping(inputBody, headers, props)

    byte[] binary_image = props.get("binary_image")
    byte[] binary_pdf = props.get("binary_pdf")

    outputFileImage.bytes = binary_image
    outputFilePDF.bytes = binary_pdf
}

def DoMapping(String body, Map headers, Map properties) {
    def InputPayload = new XmlSlurper().parseText(body)

    InputPayload.row.each{ this_row ->
        def binary_image = this_row.image.toString().decodeBase64()
        def binary_pdf = this_row.pdf.toString().decodeBase64()

        properties.put("binary_image", binary_image)
        properties.put("binary_pdf", binary_pdf)
    }

    return ""
}












