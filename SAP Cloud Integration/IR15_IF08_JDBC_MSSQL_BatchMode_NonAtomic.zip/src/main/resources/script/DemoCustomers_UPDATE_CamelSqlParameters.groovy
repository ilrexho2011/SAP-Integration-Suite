import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	message.setBody('UPDATE DemoCustomers SET CompanyName = ? WHERE CustomerID = ?')
	
    def paramList = []
    def param = []
    
    param = []
	param.add('A Name Updated from CamelSqlParameters')
    param.add('AAAAA')
    paramList.add(param)
    
    param = []
	param.add('B Name Updated from CamelSqlParameters')
    param.add('BBBBB')
    paramList.add(param)
    
    param = []
	param.add('C Name Updated from CamelSqlParameters')
    param.add('CCCCC')
    paramList.add(param)
    
    
    message.setHeader("CamelSqlParameters", paramList)
    
    return message
}