import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	message.setBody('DELETE FROM DemoCustomers WHERE CustomerID = ?')
	
    def paramList = []
    def param = []
    
    param = []
    param.add('AAAAA')
    paramList.add(param)
    
    param = []
    param.add('BBBBB')
    paramList.add(param)
    
    param = []
    param.add('CCCCC')
    paramList.add(param)
    
    
    message.setHeader("CamelSqlParameters", paramList)
    
    return message
}