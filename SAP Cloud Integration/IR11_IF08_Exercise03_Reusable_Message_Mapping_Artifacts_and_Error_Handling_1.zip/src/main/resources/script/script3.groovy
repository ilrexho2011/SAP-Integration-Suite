import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def headers = message.getHeaders();
    def properties = message.getProperties();
    def body = message.getBody(String.class);

    // Extract OrderID and Error message
    def orderID = headers.get("OrderID") ?: "Unknown"
    def errorMessage = properties.get("CamelExceptionCaught")?.getMessage() ?: "Unknown error"

    // Format the error log
    def errorLog = "{ \"OrderID\": \"${orderID}\", \"Error\": \"${errorMessage}\" }"

    // Set the message body to the error log
    message.setBody(errorLog);
    
    return message;
}
