import com.sap.it.api.mapping.*;

def String convertPrice(int TotalAmount, String Currency) {
    def conversionRates = ['USD': 1.21, 'EUR': 1.35] // Exchange rates to CAD

    // Get the conversion rate for the currency (default to 1 if not found)
    def Double rate = conversionRates.get(Currency, 1)

    // Convert price
    return (TotalAmount as BigDecimal) * (rate as BigDecimal)
}