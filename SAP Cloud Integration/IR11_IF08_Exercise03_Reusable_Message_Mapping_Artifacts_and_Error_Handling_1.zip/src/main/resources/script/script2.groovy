import groovy.xml.XmlSlurper
import groovy.xml.MarkupBuilder
import java.io.StringWriter

// Simulating input payload (Replace with message.getBody(String) in actual CPI)
def inputXml = '''<Order>
    <OrderID>12346</OrderID>
    <CustomerName></CustomerName>  <TotalAmount>InvalidValue</TotalAmount>
    <Currency>EUR</Currency>
</Order>'''

// Parse the input XML
def xml = new XmlSlurper().parseText(inputXml)

// Extract values
def orderId = xml.OrderID.text()
def customerName = xml.CustomerName.text()
def totalAmount = xml.TotalAmount.text()

// Initialize error message list
def errorMessages = []

// Validate CustomerName (must not be empty)
if (!customerName || customerName.trim().isEmpty()) { // More concise check
    errorMessages << "Missing mandatory field: CustomerName"
}

// Validate TotalAmount (must be a valid number and greater than or equal to 0)
try {
    BigDecimal amount = new BigDecimal(totalAmount) // Use BigDecimal for more robust number handling
    if (amount < 0) {
      errorMessages << "TotalAmount must be non-negative"
    }
} catch (NumberFormatException e) {
    errorMessages << "Invalid TotalAmount value: " + totalAmount // Include the invalid value
}


// Construct output XML
def writer = new StringWriter()
def xmlBuilder = new MarkupBuilder(writer)

xmlBuilder.ERPOrders {
    ERPOrder {
        ID(orderId)
        if (errorMessages) {
            Error(errorMessages.join(" or ")) // Join errors with "or"
        }
    }
}

// Print final XML output (For testing in CPI, replace with message.setBody(writer.toString()))
def finalOutput = writer.toString()
println finalOutput