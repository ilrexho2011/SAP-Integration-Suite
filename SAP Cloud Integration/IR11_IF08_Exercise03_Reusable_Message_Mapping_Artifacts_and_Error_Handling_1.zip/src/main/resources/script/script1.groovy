import com.sap.gateway.ip.core.customdev.util.Message;

import java.text.SimpleDateFormat;

def Message processData(Message message) {

    def body = message.getBody();
    
    def properties = message.getProperties();
    def headers = message.getHeaders();
    def date = new Date()
    theDate = new SimpleDateFormat("dd/MM/yyyy")
    theTime = new SimpleDateFormat("HH:mm:ss")
    
    progID = properties.get("progID");
    errorDetails = properties.get("ErrorMessage")
    String fileNamex = properties.get("CamelFileExchangeFile")
    
    String fileName2 = ""
    if (fileNamex?.trim()) {
        fileName2 = fileNamex.replace("RemoteFile[","")
        fileName2 = fileName2.replace("]","")
    }
    
    Output = "There was an error in Iflow : " + progID + "\n\n"
    Output += "This error happened at " + theTime.format(date) + " on " + theDate.format(date) + "\n\n"
    
    if (fileName2?.trim()) {
        Output += "The file Name was : " + fileName2 + "\n\n"}
    Output += "Error details : " + errorDetails
    
    message.setBody(Output)
    return message;
}