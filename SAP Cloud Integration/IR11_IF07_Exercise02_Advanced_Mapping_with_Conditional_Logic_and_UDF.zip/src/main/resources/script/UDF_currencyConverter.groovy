/* https://computerhouse.al */

import com.sap.it.api.mapping.MappingContext
import com.sap.gateway.ip.core.customdev.util.Message
import java.math.BigDecimal

def String convertPrice(String price, String currencyRate, MappingContext context) {
    	return (price as BigDecimal) * (currencyRate as BigDecimal)
}