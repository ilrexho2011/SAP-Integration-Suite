/* https://computerhouse.al */

import com.sap.it.api.mapping.MappingContext
import com.sap.gateway.ip.core.customdev.util.Message
import java.math.BigDecimal

def convertCurrency(price, currency) {
def conversionRates = ['USD': 1.21, 'EUR': 1.35] // Example rates
return (price as BigDecimal) * (conversionRates[currency] ?: 1)
}
convertCurrency(input1, input2)
