import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message
import java.math.BigDecimal

def String convertPrice(String price, String currencyRate, MappingContext context) {
    	def conversionRates = ['USD': 1.21, 'EUR': 1.35] // Example rates
	return (price as BigDecimal) * (conversionRates[currency]as BigDecimal ?: 1)
	}
	convertCurrency(price, currency)