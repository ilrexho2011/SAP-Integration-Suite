/* https://computerhouse.al */

import com.sap.it.api.mapping.MappingContext
import com.sap.gateway.ip.core.customdev.util.Message
import java.math.BigDecimal

def String convertPrice(String price, String currencyRate, MappingContext context) {
    	def conversionRates = ['USD': 85, 'EUR': 90] // Example rates
        return (price as BigDecimal) * (conversionRates[currency] ?: 1)
}