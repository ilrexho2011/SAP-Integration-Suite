import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)

    // Parse JSON
    def json
    try {
        json = new JsonSlurper().parseText(body)
    } catch (Exception e) {
        throw new Exception("Error parsing JSON: " + e.message)
    }

    // Debugging: Store JSON in logs
    message.setProperty("debug_json", json.toString())

    // Check if "sheets" exist
    if (!json.containsKey("sheets") || !(json.sheets instanceof List) || json.sheets.isEmpty()) {
        throw new Exception("Invalid JSON format: 'sheets' must be a non-empty array")
    }

    // Extract data from the first sheet
    def sheet = json.sheets[0]
    def sheetTitle = sheet.properties.title

    // Construct XML
    def xmlOutput = new StringBuilder()
    xmlOutput.append("<Spreadsheet>")
    xmlOutput.append("<Sheet name='" + escapeXml(sheetTitle) + "'>")

    xmlOutput.append("</Sheet>")
    xmlOutput.append("</Spreadsheet>")

    // Set the XML as the message body
    message.setBody(xmlOutput.toString())
    return message
}

// Function to escape XML special characters
def String escapeXml(String input) {
    return input.replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll("\"", "&quot;")
        .replaceAll("'", "&apos;")
}