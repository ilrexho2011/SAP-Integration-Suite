/* https://computehouse.al */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def headers = message.getHeaders()
    def properties = message.getProperties()

    message.setBody(DoMapping(body, headers, properties))

    return message
}

//Need comment this TestRun() before upload to SAP CI. This TestRun() for local debug only
//TestRun()

void TestRun() {
    def scriptDir = new File(getClass().protectionDomain.codeSource.location.toURI().path).parent
    def dataDir = scriptDir + "\\Data"

    Map headers = [:]
    Map props = [:]

    File inputFileImage = new File("$dataDir\\Wikipedia-logo-v2.svg.png")
    File inputFilePDF = new File("$dataDir\\FSD_IntegrationSuite.pdf")

    props.put("binary_image", inputFileImage.getBytes())
    props.put("binary_pdf", inputFilePDF.getBytes())

    File outputFile = new File("$dataDir\\XML_embedded_PDF_and_Image.txt")

    def outputBody = DoMapping("", headers, props)

    println outputBody
    outputFile.write outputBody
}

def DoMapping(String body, Map headers, Map properties) {
    def builder = new StreamingMarkupBuilder()

    byte[] binary_image = properties.get("binary_image")
    byte[] binary_pdf = properties.get("binary_pdf")

    //MAPPING
    def writer = builder.bind{
        mkp.xmlDeclaration()

        root{
            row{
                image(binary_image.encodeBase64().toString())
                pdf(binary_pdf.encodeBase64().toString())
            }
        }
    }

    //WRITING
    //def output = writer.toString()
    def output = XmlUtil.serialize(writer.toString())

    return output
}












