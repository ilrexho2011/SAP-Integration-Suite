import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Extract the error description sent by Postman
    def errorText = message.getBody(String)

    // Define the full ChatGPT request payload as a Map
    def payload = [
        model: "gpt-4o",
        messages: [
            [
                role: "system",
                content: "You are a software assistant that helps users debug and understand API errors."
            ],
            [
                role: "user",
                content: errorText
            ]
        ],
        temperature: 0.2
    ]

    // Convert the map to JSON string
    def jsonString = JsonOutput.toJson(payload)
    message.setBody(jsonString)

    return message
}